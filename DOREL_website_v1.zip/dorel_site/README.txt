DORÉL — The Art of Luxury
First visual prototype.

Open index.html in a browser.
The product images are temporary demo images and can later be replaced.
The currency/language selectors are visual placeholders in this first version.
